/*
 * plc-siemens-s7-smart200.h
 *
 *  Created on: 2018年11月28日
 *      Author: fanxiaobin
 */

#ifndef PLC_SIEMENS_S7_SMART200_H_
#define PLC_SIEMENS_S7_SMART200_H_

void SIEMENS_S7_SMART200_Init();
void SIEMENS_S7_SMART200_Read_And_Send();
void SIEMENS_S7_SMART200_End();

#endif /* PLC_SIEMENS_S7_SMART200_H_ */
